import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Candidate, Requisition, Stage } from './types';
import * as api from './services/api';
import Header from './components/Header';
import MetricsCards from './components/MetricsCards';
import RequisitionOverview from './components/RequisitionOverview';
import FunnelChart from './components/FunnelChart';
import KanbanBoard from './components/KanbanBoard';
import CandidateModal from './components/CandidateModal';
import { TemperatureMeter } from './components/TemperatureMeter';
import { SearchIcon } from './components/icons';

const App: React.FC = () => {
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [requisitions, setRequisitions] = useState<Requisition[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [selectedCandidate, setSelectedCandidate] = useState<Candidate | null>(null);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [selectedHiringManager, setSelectedHiringManager] = useState<string>('all');
  const [selectedRequisitionId, setSelectedRequisitionId] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const fetchData = useCallback(async () => {
    // Don't set loading to true here to avoid flicker on every data change
    try {
      const [reqs, cands] = await Promise.all([
        api.getRequisitions(),
        api.getCandidates(),
      ]);
      setRequisitions(reqs);
      setCandidates(cands);
    } catch (error) {
      console.error("Failed to fetch data", error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    setLoading(true);
    fetchData();
  }, [fetchData]);
  
  const handleUpload = async (saveFunction: (data: any) => Promise<void>, data: any) => {
    setLoading(true);
    try {
        await saveFunction(data);
        await fetchData();
    } catch (error) {
        console.error("Failed to upload data:", error);
    } finally {
        setLoading(false);
    }
  };

  const handleRequisitionsUpload = (newRequisitions: Requisition[]) => {
      handleUpload(api.saveRequisitions, newRequisitions);
  };
  
  const handleCandidatesUpload = (newCandidates: Candidate[]) => {
      handleUpload(api.saveCandidates, newCandidates);
  };

  const handleSelectCandidate = (candidate: Candidate) => {
    setSelectedCandidate(candidate);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedCandidate(null);
  };

  const handleUpdateStage = async (candidateId: string, newStage: Stage) => {
    try {
      await api.updateCandidateStage(candidateId, newStage);
      await fetchData();
    } catch (error) {
      console.error("Failed to update candidate stage:", error);
    }
  };

  const handleUpdateRequisition = async (candidateId: string, newRequisitionId: string) => {
    try {
      await api.updateCandidateRequisition(candidateId, newRequisitionId);
      await fetchData();
    } catch (error) {
      console.error("Failed to update candidate requisition:", error);
    }
  };

  const handleUpdateRequisitionDate = async (
    requisitionId: string,
    dateField: keyof Pick<Requisition, 'approvalDate' | 'briefingCallDate' | 'jobPostedDate'>
  ) => {
    try {
      await api.updateRequisitionDate(requisitionId, dateField);
      await fetchData();
    } catch (error) {
      console.error(`Failed to update requisition date field ${dateField}:`, error);
    }
  };

  const hiringManagers = useMemo(() => [
    ...new Set(requisitions.map(r => r.hiringManager))
  ], [requisitions]);

  const availableRequisitionsForFilter = useMemo(() => {
    return requisitions.filter(r => 
        r.status === 'Open' &&
        (selectedHiringManager === 'all' || r.hiringManager === selectedHiringManager)
    );
  }, [requisitions, selectedHiringManager]);

  useEffect(() => {
    if (selectedRequisitionId !== 'all' && !availableRequisitionsForFilter.some(r => r.id === selectedRequisitionId)) {
        setSelectedRequisitionId('all');
    }
  }, [selectedRequisitionId, availableRequisitionsForFilter]);

  
  const filteredData = useMemo(() => {
    const lowerCaseQuery = searchQuery.toLowerCase().trim();

    let currentReqs = requisitions;
    let currentCands = candidates;

    // Apply HM filter
    if (selectedHiringManager !== 'all') {
        currentReqs = currentReqs.filter(r => r.hiringManager === selectedHiringManager);
    }

    // Apply Requisition filter
    if (selectedRequisitionId !== 'all') {
        currentReqs = currentReqs.filter(r => r.id === selectedRequisitionId);
    }

    // Apply Search filter
    if (lowerCaseQuery) {
        const matchingCandIds = new Set(
            currentCands
                .filter(c => c.name.toLowerCase().includes(lowerCaseQuery))
                .map(c => c.id)
        );
        
        const matchingReqsFromSearch = currentReqs.filter(r =>
            r.title.toLowerCase().includes(lowerCaseQuery) ||
            r.id.toLowerCase().includes(lowerCaseQuery)
        );
        const matchingReqIdsFromSearch = new Set(matchingReqsFromSearch.map(r => r.id));

        const reqsContainingMatchingCands = new Set(
            currentCands
                .filter(c => matchingCandIds.has(c.id))
                .map(c => c.jobRequisitionId)
        );

        const finalReqIds = new Set([...matchingReqIdsFromSearch, ...reqsContainingMatchingCands]);

        currentReqs = currentReqs.filter(r => finalReqIds.has(r.id));
        
        const finalReqIdsSet = new Set(currentReqs.map(r => r.id));
        currentCands = candidates.filter(c => 
            (matchingCandIds.has(c.id) || finalReqIdsSet.has(c.jobRequisitionId))
        );
    }

    // Finally, ensure candidate list is in sync with the final requisition list
    const finalReqsIds = new Set(currentReqs.map(r => r.id));
    currentCands = currentCands.filter(c => finalReqsIds.has(c.jobRequisitionId));

    return { requisitions: currentReqs, candidates: currentCands };
  }, [searchQuery, selectedHiringManager, selectedRequisitionId, candidates, requisitions]);
  
  const selectedRequisitionObject = useMemo(() => {
    if (selectedRequisitionId === 'all') return null;
    return requisitions.find(r => r.id === selectedRequisitionId) || null;
  }, [requisitions, selectedRequisitionId]);


  const selectedRequisitionForModal = requisitions.find(r => r.id === selectedCandidate?.jobRequisitionId) || null;

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="text-xl text-slate-400">Loading Dashboard...</div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8">
      <Header 
        onUploadRequisitions={handleRequisitionsUpload}
        onUploadCandidates={handleCandidatesUpload}
      />
      
      <div className="my-6 grid grid-cols-1 md:grid-cols-3 items-end gap-4">
        <div>
          <label htmlFor="hm-filter" className="block text-sm font-medium text-slate-400 mb-2">Filter by Hiring Manager</label>
          <select 
              id="hm-filter"
              value={selectedHiringManager} 
              onChange={e => setSelectedHiringManager(e.target.value)}
              className="w-full bg-slate-700 border border-slate-600 rounded-md p-2 text-slate-100 focus:ring-2 focus:ring-brand-primary focus:outline-none"
              aria-label="Filter by hiring manager"
          >
              <option value="all">All Hiring Managers</option>
              {hiringManagers.map(hm => (
                  <option key={hm} value={hm}>{hm}</option>
              ))}
          </select>
        </div>
        <div>
          <label htmlFor="req-filter" className="block text-sm font-medium text-slate-400 mb-2">Filter by Requisition</label>
          <select 
              id="req-filter"
              value={selectedRequisitionId} 
              onChange={e => setSelectedRequisitionId(e.target.value)}
              className="w-full bg-slate-700 border border-slate-600 rounded-md p-2 text-slate-100 focus:ring-2 focus:ring-brand-primary focus:outline-none"
              aria-label="Filter by requisition"
          >
              <option value="all">All Requisitions</option>
              {availableRequisitionsForFilter.map(req => (
                  <option key={req.id} value={req.id}>{req.title}</option>
              ))}
          </select>
        </div>
        <div className="relative md:col-span-1">
          <label htmlFor="search-box" className="block text-sm font-medium text-slate-400 mb-2">Search</label>
          <input
            id="search-box"
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Candidate name, position, or req ID..."
            className="w-full bg-slate-700 border border-slate-600 rounded-md p-2 pl-10 text-slate-100 focus:ring-2 focus:ring-brand-primary focus:outline-none"
          />
          <SearchIcon className="absolute left-3 bottom-2.5 w-5 h-5 text-slate-400" />
        </div>
      </div>

      {selectedRequisitionObject && (
        <div className="mb-8">
          <TemperatureMeter 
            requisition={selectedRequisitionObject} 
            candidates={filteredData.candidates.filter(c => c.jobRequisitionId === selectedRequisitionId)} 
            onUpdateRequisitionDate={handleUpdateRequisitionDate}
          />
        </div>
      )}

      <MetricsCards candidates={filteredData.candidates} requisitions={filteredData.requisitions} />
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mt-8">
        <div className="lg:col-span-2">
            <RequisitionOverview requisitions={filteredData.requisitions} candidates={filteredData.candidates} selectedRequisitionId={selectedRequisitionId === 'all' ? null : selectedRequisitionId}/>
        </div>
        <div className="lg:col-span-1">
          <FunnelChart candidates={filteredData.candidates} />
        </div>
      </div>
      <KanbanBoard candidates={filteredData.candidates} requisitions={requisitions} onSelectCandidate={handleSelectCandidate} />
      <CandidateModal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        candidate={selectedCandidate}
        requisition={selectedRequisitionForModal}
        allRequisitions={requisitions.filter(r => r.status === 'Open')}
        onUpdateStage={handleUpdateStage}
        onUpdateRequisition={handleUpdateRequisition}
      />
    </div>
  );
};

export default App;