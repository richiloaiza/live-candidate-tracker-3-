
import { Stage, Candidate, Requisition, KpiConfig } from './types';

// The canonical order of stages in the funnel
export const STAGE_ORDER: Stage[] = [
  Stage.APPLIED,
  Stage.SCREENING,
  Stage.INTERVIEW_1,
  Stage.INTERVIEW_2,
  Stage.OFFER,
  Stage.OFFER_ACCEPTED,
  Stage.PREBOARDING,
];

// SLA thresholds in days for how long a candidate can be in a stage
export const SLA_THRESHOLDS = {
  [Stage.SCREENING]: 7,
  [Stage.INTERVIEW_1]: 10,
  [Stage.INTERVIEW_2]: 10,
  [Stage.OFFER]: 7,
  [Stage.OFFER_ACCEPTED]: 5,
  [Stage.PREBOARDING]: 10,
  NO_MOVEMENT_ALERT: 21,
  NO_BRIEFING_CALL: 5,
  NO_CVS_SCREENED: 10,
  TIME_TO_HIRE_ESCALATION: 45,
};

// KPIs for the Requisition Health temperature meter based on the provided timeline
export const REQUISITION_KPI_CONFIG: KpiConfig[] = [
  { key: 'req-approval', label: 'Requisition Approval', requisitionDateField: 'approvalDate', targetMin: 0, targetMax: 2 },
  { key: 'briefing-call', label: 'Intake/Briefing Call', requisitionDateField: 'briefingCallDate', targetMin: 2, targetMax: 3 },
  { key: 'job-posting', label: 'Job Posting & Sourcing', requisitionDateField: 'jobPostedDate', targetMin: 3, targetMax: 4 },
  { key: 'first-cv', label: 'First CVs Submitted', stage: Stage.SCREENING, targetMin: 5, targetMax: 10 },
  { key: 'first-interview-1', label: 'Interviews (1st Round)', stage: Stage.INTERVIEW_1, targetMin: 10, targetMax: 20 },
  { key: 'first-interview-2', label: 'Interviews (2nd/Final Round)', stage: Stage.INTERVIEW_2, targetMin: 20, targetMax: 28 },
  { key: 'offer-decision', label: 'Selection & Offer Decision', stage: Stage.OFFER, targetMin: 28, targetMax: 30 },
  { key: 'offer-accepted', label: 'Offer Accepted', stage: Stage.OFFER_ACCEPTED, targetMin: 30, targetMax: 35 },
  { key: 'preboarding', label: 'Preboarding / Start Date Planning', stage: Stage.PREBOARDING, targetMin: 35, targetMax: 45 },
];


const today = new Date();
const daysAgo = (days: number): string => {
  const date = new Date();
  date.setDate(today.getDate() - days);
  return date.toISOString();
};

export const MOCK_REQUISITIONS: Requisition[] = [
  { id: 'REQ-001', title: 'Senior Frontend Engineer', openDate: daysAgo(50), hiringManager: 'Derek Shepherd', recruiter: 'Anna Rees', status: 'Open', approvalDate: daysAgo(50), briefingCallDate: daysAgo(48), jobPostedDate: daysAgo(47) },
  { id: 'REQ-002', title: 'UX/UI Designer', openDate: daysAgo(25), hiringManager: 'Meredith Grey', recruiter: 'John Doe', status: 'Open', approvalDate: daysAgo(25), briefingCallDate: daysAgo(24), jobPostedDate: null },
  { id: 'REQ-003', title: 'Backend Developer', openDate: daysAgo(12), hiringManager: 'Cristina Yang', recruiter: 'Anna Rees', status: 'Open', approvalDate: daysAgo(12), briefingCallDate: null, jobPostedDate: null },
  { id: 'REQ-004', title: 'Product Manager', openDate: daysAgo(6), hiringManager: 'Alex Karev', recruiter: 'Jane Smith', status: 'Open', approvalDate: null, briefingCallDate: null, jobPostedDate: null },
  { id: 'REQ-005', title: 'Data Scientist', openDate: daysAgo(90), hiringManager: 'Miranda Bailey', recruiter: 'John Doe', status: 'Closed', approvalDate: daysAgo(90), briefingCallDate: daysAgo(88), jobPostedDate: daysAgo(87) },
];

export const MOCK_CANDIDATES: Candidate[] = [
  // Candidates for REQ-001
  { id: 'CAND-101', name: 'Jane Doe', email: 'jane.doe@example.com', jobRequisitionId: 'REQ-001', currentStage: Stage.INTERVIEW_2, applicationDate: daysAgo(45), stageHistory: [{ stage: Stage.APPLIED, date: daysAgo(45) }, { stage: Stage.SCREENING, date: daysAgo(42) }, { stage: Stage.INTERVIEW_1, date: daysAgo(30) }, { stage: Stage.INTERVIEW_2, date: daysAgo(15) }], recruiter: 'Anna Rees', resumeUrl: '#' },
  { id: 'CAND-102', name: 'John Smith', email: 'john.smith@example.com', jobRequisitionId: 'REQ-001', currentStage: Stage.OFFER, applicationDate: daysAgo(40), stageHistory: [{ stage: Stage.APPLIED, date: daysAgo(40) }, { stage: Stage.SCREENING, date: daysAgo(37) }, { stage: Stage.INTERVIEW_1, date: daysAgo(25) }, { stage: Stage.INTERVIEW_2, date: daysAgo(15) }, { stage: Stage.OFFER, date: daysAgo(3) }], recruiter: 'Anna Rees', resumeUrl: '#' },
  { id: 'CAND-103', name: 'Peter Jones', email: 'peter.jones@example.com', jobRequisitionId: 'REQ-001', currentStage: Stage.SCREENING, applicationDate: daysAgo(22), stageHistory: [{ stage: Stage.APPLIED, date: daysAgo(22) }, { stage: Stage.SCREENING, date: daysAgo(8) }], recruiter: 'Anna Rees', resumeUrl: '#' },
  { id: 'CAND-104', name: 'Mary Johnson', email: 'mary.j@example.com', jobRequisitionId: 'REQ-001', currentStage: Stage.OFFER_ACCEPTED, applicationDate: daysAgo(60), stageHistory: [{ stage: Stage.APPLIED, date: daysAgo(60) }, { stage: Stage.SCREENING, date: daysAgo(55) }, { stage: Stage.INTERVIEW_1, date: daysAgo(45) }, { stage: Stage.INTERVIEW_2, date: daysAgo(42) }, { stage: Stage.OFFER, date: daysAgo(40) }, { stage: Stage.OFFER_ACCEPTED, date: daysAgo(34) }], recruiter: 'Anna Rees', resumeUrl: '#' },
  { id: 'CAND-109', name: 'Stuck Candidate', email: 'stuck.cand@example.com', jobRequisitionId: 'REQ-001', currentStage: Stage.SCREENING, applicationDate: daysAgo(30), stageHistory: [{ stage: Stage.APPLIED, date: daysAgo(30) }, { stage: Stage.SCREENING, date: daysAgo(25) }], recruiter: 'Anna Rees', resumeUrl: '#' },


  // Candidates for REQ-002
  { id: 'CAND-201', name: 'Alice Williams', email: 'alice.w@example.com', jobRequisitionId: 'REQ-002', currentStage: Stage.APPLIED, applicationDate: daysAgo(24), stageHistory: [{ stage: Stage.APPLIED, date: daysAgo(24) }], recruiter: 'John Doe', resumeUrl: '#' },
  { id: 'CAND-202', name: 'Bob Brown', email: 'bob.b@example.com', jobRequisitionId: 'REQ-002', currentStage: Stage.INTERVIEW_1, applicationDate: daysAgo(20), stageHistory: [{ stage: Stage.APPLIED, date: daysAgo(20) }, { stage: Stage.SCREENING, date: daysAgo(15) }, { stage: Stage.INTERVIEW_1, date: daysAgo(5) }], recruiter: 'John Doe', resumeUrl: '#' },

  // Candidates for REQ-003
  { id: 'CAND-301', name: 'Charlie Davis', email: 'charlie.d@example.com', jobRequisitionId: 'REQ-003', currentStage: Stage.SCREENING, applicationDate: daysAgo(11), stageHistory: [{ stage: Stage.APPLIED, date: daysAgo(11) }, { stage: Stage.SCREENING, date: daysAgo(9) }], recruiter: 'Anna Rees', resumeUrl: '#' },
];
