
export enum Stage {
  APPLIED = 'Applied',
  SCREENING = 'Screening',
  INTERVIEW_1 = 'Interview (1st Round)',
  INTERVIEW_2 = 'Interview (2nd/Final Round)',
  OFFER = 'Offer Decision',
  OFFER_ACCEPTED = 'Offer Accepted',
  PREBOARDING = 'Preboarding',
  REJECTED = 'Rejected',
}

export interface StageHistoryItem {
  stage: Stage;
  date: string; // ISO date string
}

export interface Candidate {
  id: string;
  name: string;
  email: string;
  jobRequisitionId: string;
  currentStage: Stage;
  applicationDate: string; // ISO date string
  stageHistory: StageHistoryItem[];
  recruiter: string;
  resumeUrl: string;
}

export interface Requisition {
  id: string;
  title: string;
  openDate: string; // ISO date string
  hiringManager: string;
  recruiter: string;
  status: 'Open' | 'Closed' | 'On Hold';
  approvalDate: string | null;
  briefingCallDate: string | null;
  jobPostedDate: string | null;
}

export enum KpiStatus {
  PENDING = 'Pending',
  ON_TIME = 'On Time',
  AT_RISK = 'At Risk',
  DELAYED = 'Delayed',
  DONE = 'Done',
}

export interface KpiConfig {
  key: string;
  label: string;
  stage?: Stage;
  requisitionDateField?: keyof Pick<Requisition, 'approvalDate' | 'briefingCallDate' | 'jobPostedDate'>;
  targetMin: number;
  targetMax: number;
}
