
import React, { useMemo } from 'react';
import { Candidate, Requisition, Stage } from '../types';
import { STAGE_ORDER } from '../constants';
import CandidateCard from './CandidateCard';

interface KanbanBoardProps {
  candidates: Candidate[];
  requisitions: Requisition[];
  onSelectCandidate: (candidate: Candidate) => void;
}

const KanbanBoard: React.FC<KanbanBoardProps> = ({ candidates, requisitions, onSelectCandidate }) => {
  const groupedCandidates = useMemo(() => {
    const groups = STAGE_ORDER.reduce((acc, stage) => {
      acc[stage] = [];
      return acc;
    }, {} as Record<Stage, Candidate[]>);

    candidates.forEach(candidate => {
      if (groups[candidate.currentStage]) {
        groups[candidate.currentStage].push(candidate);
      }
    });
    return groups;
  }, [candidates]);
  
  const requisitionsMap = useMemo(() => 
    requisitions.reduce((acc, req) => {
      acc[req.id] = req;
      return acc;
    }, {} as Record<string, Requisition>), 
  [requisitions]);

  return (
    <div className="mt-8">
        <h3 className="text-lg font-semibold text-slate-100 mb-4">Candidate Pipeline</h3>
        <div className="flex space-x-4 overflow-x-auto pb-4">
        {STAGE_ORDER.map(stage => (
            <div key={stage} className="bg-slate-800 rounded-lg p-3 w-72 flex-shrink-0">
            <h3 className="font-semibold text-slate-100 mb-4 px-2 flex justify-between items-center">
                <span>{stage}</span>
                <span className="text-sm bg-slate-700 text-slate-300 rounded-full px-2 py-0.5">
                    {groupedCandidates[stage].length}
                </span>
            </h3>
            <div className="h-full overflow-y-auto pr-1">
                {groupedCandidates[stage].map(candidate => (
                <CandidateCard
                    key={candidate.id}
                    candidate={candidate}
                    requisition={requisitionsMap[candidate.jobRequisitionId]}
                    onSelect={onSelectCandidate}
                />
                ))}
            </div>
            </div>
        ))}
        </div>
    </div>
  );
};

export default KanbanBoard;
