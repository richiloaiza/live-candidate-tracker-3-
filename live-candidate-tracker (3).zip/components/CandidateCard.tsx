
import React from 'react';
import { Candidate, Requisition } from '../types';
import { SLA_THRESHOLDS } from '../constants';
import { AlertTriangleIcon } from './icons';

interface CandidateCardProps {
  candidate: Candidate;
  requisition: Requisition | undefined;
  onSelect: (candidate: Candidate) => void;
}

const getDaysInCurrentStage = (candidate: Candidate): number => {
  if (candidate.stageHistory.length === 0) {
    return Math.floor((new Date().getTime() - new Date(candidate.applicationDate).getTime()) / (1000 * 60 * 60 * 24));
  }
  const lastStageEntry = candidate.stageHistory[candidate.stageHistory.length - 1];
  return Math.floor((new Date().getTime() - new Date(lastStageEntry.date).getTime()) / (1000 * 60 * 60 * 24));
};

const CandidateCard: React.FC<CandidateCardProps> = ({ candidate, requisition, onSelect }) => {
  const daysInStage = getDaysInCurrentStage(candidate);
  const slaThreshold = SLA_THRESHOLDS[candidate.currentStage as keyof typeof SLA_THRESHOLDS];
  const isOverSLA = slaThreshold && daysInStage > slaThreshold;

  return (
    <div
      onClick={() => onSelect(candidate)}
      className="bg-slate-700 p-4 rounded-lg shadow-md mb-3 cursor-pointer hover:bg-slate-600 transition-all duration-200 border-l-4 border-transparent hover:border-brand-secondary"
    >
      <div className="flex justify-between items-start">
        <div>
          <h4 className="font-bold text-slate-100">{candidate.name}</h4>
          <p className="text-xs text-slate-400">{requisition?.title || 'N/A'}</p>
        </div>
        {isOverSLA && (
          <div title={`Exceeded SLA of ${slaThreshold} days`}>
            <AlertTriangleIcon className="h-5 w-5 text-red-500" />
          </div>
        )}
      </div>
      <div className="text-sm text-slate-300 mt-3">
        {daysInStage} day{daysInStage !== 1 ? 's' : ''} in stage
      </div>
    </div>
  );
};

export default CandidateCard;
