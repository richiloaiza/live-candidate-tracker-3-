
import React, { useMemo } from 'react';
import { Candidate, Requisition, Stage } from '../types';
import Card from './ui/Card';
import { UsersIcon, ClockIcon, TargetIcon, BriefcaseIcon } from './icons';

interface MetricsCardsProps {
  candidates: Candidate[];
  requisitions: Requisition[];
}

const getDaysBetween = (date1: string, date2: string) => {
    return Math.round((new Date(date2).getTime() - new Date(date1).getTime()) / (1000 * 3600 * 24));
};

const MetricCard: React.FC<{ icon: React.ReactNode; label: string; value: string | number; }> = ({ icon, label, value }) => (
    <Card className="flex items-center p-4">
        <div className="p-3 bg-slate-700 rounded-lg mr-4">{icon}</div>
        <div>
            <div className="text-slate-400 text-sm">{label}</div>
            <div className="text-2xl font-bold text-slate-100">{value}</div>
        </div>
    </Card>
);

const MetricsCards: React.FC<MetricsCardsProps> = ({ candidates, requisitions }) => {
    const { avgTimeToHire, conversionRate, activeCandidates } = useMemo(() => {
        const hiredCandidates = candidates.filter(c => c.currentStage === Stage.OFFER_ACCEPTED);
        
        const timeToHireValues = hiredCandidates
            .map(c => {
                const hiredStage = c.stageHistory.find(sh => sh.stage === Stage.OFFER_ACCEPTED);
                if (hiredStage) {
                    return getDaysBetween(c.applicationDate, hiredStage.date);
                }
                return null;
            })
            .filter((d): d is number => d !== null);

        const avgTimeToHire = timeToHireValues.length > 0
            ? Math.round(timeToHireValues.reduce((a, b) => a + b, 0) / timeToHireValues.length)
            : 0;

        const conversionRate = candidates.length > 0
            ? ((hiredCandidates.length / candidates.length) * 100).toFixed(1)
            : 0;
            
        const activeCandidates = candidates.filter(c => c.currentStage !== Stage.OFFER_ACCEPTED && c.currentStage !== Stage.REJECTED && c.currentStage !== Stage.PREBOARDING).length;

        return { avgTimeToHire, conversionRate, activeCandidates };
    }, [candidates]);

    const openRequisitions = requisitions.filter(r => r.status === 'Open').length;

    return (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <MetricCard icon={<BriefcaseIcon className="w-6 h-6 text-blue-400"/>} label="Open Requisitions" value={openRequisitions} />
            <MetricCard icon={<UsersIcon className="w-6 h-6 text-green-400"/>} label="Active Candidates" value={activeCandidates} />
            <MetricCard icon={<ClockIcon className="w-6 h-6 text-yellow-400"/>} label="Avg. Time to Offer Accept" value={avgTimeToHire || 'N/A'} />
            <MetricCard icon={<TargetIcon className="w-6 h-6 text-purple-400"/>} label="Overall Conversion Rate" value={`${conversionRate}%`} />
        </div>
    );
};

export default MetricsCards;
