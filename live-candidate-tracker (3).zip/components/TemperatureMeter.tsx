
import React, { useMemo } from 'react';
import { Requisition, Candidate, KpiStatus, KpiConfig } from '../types';
import { REQUISITION_KPI_CONFIG } from '../constants';
import Card from './ui/Card';
import { AlertTriangleIcon, CheckCircle2Icon, ClockIcon } from './icons';

const getDaysSince = (dateString: string) => {
    if (!dateString) return 0;
    return Math.floor((new Date().getTime() - new Date(dateString).getTime()) / (1000 * 60 * 60 * 24));
};

const KpiStatusIndicator: React.FC<{ status: KpiStatus }> = ({ status }) => {
    const statusConfig = {
        [KpiStatus.DONE]: { icon: <CheckCircle2Icon className="w-5 h-5 text-green-400" />, textClass: "text-green-400" },
        [KpiStatus.ON_TIME]: { icon: <CheckCircle2Icon className="w-5 h-5 text-green-400" />, textClass: "text-green-400" },
        [KpiStatus.AT_RISK]: { icon: <AlertTriangleIcon className="w-5 h-5 text-yellow-400" />, textClass: "text-yellow-400" },
        [KpiStatus.DELAYED]: { icon: <AlertTriangleIcon className="w-5 h-5 text-red-400" />, textClass: "text-red-400" },
        [KpiStatus.PENDING]: { icon: <ClockIcon className="w-5 h-5 text-slate-400" />, textClass: "text-slate-400" },
    };
    const config = statusConfig[status];
    return (
        <div className="flex items-center space-x-2">
            {config.icon}
            <span className={`font-semibold ${config.textClass}`}>{status}</span>
        </div>
    );
};

interface TemperatureMeterProps {
  requisition: Requisition;
  candidates: Candidate[];
  onUpdateRequisitionDate: (requisitionId: string, dateField: keyof Pick<Requisition, 'approvalDate' | 'briefingCallDate' | 'jobPostedDate'>) => void;
}

export const TemperatureMeter: React.FC<TemperatureMeterProps> = ({ requisition, candidates, onUpdateRequisitionDate }) => {
    const kpiResults = useMemo(() => {
        const daysSinceOpen = getDaysSince(requisition.openDate);

        return REQUISITION_KPI_CONFIG.map(kpi => {
            let status: KpiStatus;
            let actualDays: number | null = null;
            let isComplete = false;

            if (kpi.requisitionDateField) {
                const completionDate = requisition[kpi.requisitionDateField];
                if (completionDate) {
                    isComplete = true;
                    const diffTime = new Date(completionDate).getTime() - new Date(requisition.openDate).getTime();
                    actualDays = Math.max(0, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));
                    status = actualDays <= kpi.targetMax ? KpiStatus.DONE : KpiStatus.DELAYED;
                } else {
                    if (daysSinceOpen < kpi.targetMin) status = KpiStatus.PENDING;
                    else if (daysSinceOpen <= kpi.targetMax) status = KpiStatus.AT_RISK;
                    else status = KpiStatus.DELAYED;
                }
            } else if (kpi.stage) {
                const earliestEventDate = candidates
                    .flatMap(c => c.stageHistory)
                    .filter(sh => sh.stage === kpi.stage)
                    .map(sh => new Date(sh.date).getTime())
                    .sort((a, b) => a - b)[0];
                
                if (earliestEventDate) {
                    isComplete = true;
                    const diffTime = earliestEventDate - new Date(requisition.openDate).getTime();
                    actualDays = Math.max(0, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));
                    status = actualDays <= kpi.targetMax ? KpiStatus.ON_TIME : KpiStatus.DELAYED;
                } else {
                    if (daysSinceOpen < kpi.targetMin) status = KpiStatus.PENDING;
                    else if (daysSinceOpen <= kpi.targetMax) status = KpiStatus.AT_RISK;
                    else status = KpiStatus.DELAYED;
                }
            } else {
                status = KpiStatus.PENDING;
            }

            return { ...kpi, status, actualDays, isComplete };
        });
    }, [requisition, candidates]);

    const overallScore = useMemo(() => {
        if (kpiResults.length === 0) return 100;
        
        const weights = {
            [KpiStatus.DONE]: 1,
            [KpiStatus.ON_TIME]: 1,
            [KpiStatus.PENDING]: 0.8,
            [KpiStatus.AT_RISK]: 0.4,
            [KpiStatus.DELAYED]: 0,
        };

        const totalScore = kpiResults.reduce((acc, result) => acc + weights[result.status], 0);
        return Math.round((totalScore / kpiResults.length) * 100);
    }, [kpiResults]);

    const scoreColor = useMemo(() => {
        if (overallScore >= 80) return 'bg-green-500';
        if (overallScore >= 50) return 'bg-yellow-500';
        return 'bg-red-500';
    }, [overallScore]);

    return (
        <Card className="flex flex-col md:flex-row gap-8 p-6">
            <div className="flex-shrink-0 flex flex-col items-center md:w-48">
                <h4 className="text-lg font-semibold mb-3 text-slate-200">Requisition Health</h4>
                <div className="relative w-20 h-48 bg-slate-700 rounded-full overflow-hidden border-2 border-slate-600">
                    <div 
                        className={`absolute bottom-0 w-full ${scoreColor} transition-all duration-500 ease-in-out`}
                        style={{ height: `${overallScore}%` }}
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                        <span className="text-white text-3xl font-bold drop-shadow-md">{overallScore}%</span>
                    </div>
                </div>
                <p className="text-slate-400 text-sm mt-3 text-center">Overall performance score based on timeline targets.</p>
            </div>
            <div className="flex-grow border-t md:border-t-0 md:border-l border-slate-700 pt-6 md:pt-0 md:pl-8">
                <h4 className="text-lg font-semibold mb-4 text-slate-200">Performance Milestones</h4>
                <ul className="space-y-3">
                    {kpiResults.map(kpi => (
                        <li key={kpi.key} className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-3 rounded-lg bg-slate-700/50 transition-all hover:bg-slate-700">
                           <div className="flex-grow">
                             <p className="font-medium text-slate-100">{kpi.label}</p>
                             <p className="text-xs text-slate-400">Target: {kpi.targetMin}-{kpi.targetMax} days</p>
                           </div>
                           <div className="flex items-center space-x-4 mt-2 sm:mt-0">
                                <KpiStatusIndicator status={kpi.status} />
                                {kpi.actualDays !== null && (
                                    <div className="text-right w-20">
                                        <p className="font-bold text-slate-100">{kpi.actualDays} days</p>
                                        <p className="text-xs text-slate-400">Actual</p>
                                    </div>
                                )}
                                {!kpi.isComplete && kpi.requisitionDateField && (
                                    <button 
                                      onClick={() => onUpdateRequisitionDate(requisition.id, kpi.requisitionDateField!)}
                                      className="text-xs bg-brand-primary text-white font-semibold py-1 px-3 rounded-md hover:bg-brand-secondary transition-colors"
                                    >
                                      Mark as Done
                                    </button>
                                )}
                           </div>
                        </li>
                    ))}
                </ul>
            </div>
        </Card>
    );
};
