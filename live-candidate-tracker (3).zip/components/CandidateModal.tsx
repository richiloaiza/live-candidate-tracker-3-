
import React, { useState, useEffect } from 'react';
import { Candidate, Requisition, Stage, StageHistoryItem } from '../types';
import Modal from './ui/Modal';
import { STAGE_ORDER } from '../constants';

interface CandidateModalProps {
  isOpen: boolean;
  onClose: () => void;
  candidate: Candidate | null;
  requisition: Requisition | null;
  allRequisitions: Requisition[];
  onUpdateStage: (candidateId: string, newStage: Stage) => void;
  onUpdateRequisition: (candidateId: string, newRequisitionId: string) => void;
}

const TimelineItem: React.FC<{ item: StageHistoryItem, isLast: boolean }> = ({ item, isLast }) => (
    <div className="flex">
        <div className="flex flex-col items-center mr-4">
            <div>
                <div className="flex items-center justify-center w-8 h-8 bg-brand-secondary rounded-full text-white">
                   {item.stage.charAt(0)}
                </div>
            </div>
            {!isLast && <div className="w-px h-full bg-slate-600"/>}
        </div>
        <div className="pb-8">
            <p className="mb-1 text-md font-semibold text-slate-100">{item.stage}</p>
            <p className="text-sm text-slate-400">{new Date(item.date).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
        </div>
    </div>
);


const CandidateModal: React.FC<CandidateModalProps> = ({ isOpen, onClose, candidate, requisition, onUpdateStage, allRequisitions, onUpdateRequisition }) => {
  const [selectedStage, setSelectedStage] = useState<Stage | ''>('');
  const [newRequisitionId, setNewRequisitionId] = useState<string>('');
  
  useEffect(() => {
    if (candidate) {
        setNewRequisitionId(candidate.jobRequisitionId);
    }
  }, [candidate]);


  if (!candidate || !requisition) return null;
  
  const handleStageUpdate = () => {
    if (selectedStage && candidate) {
      onUpdateStage(candidate.id, selectedStage);
      setSelectedStage('');
      onClose();
    }
  };

  const handleRequisitionChange = () => {
    if (newRequisitionId && candidate && candidate.jobRequisitionId !== newRequisitionId) {
      onUpdateRequisition(candidate.id, newRequisitionId);
      onClose();
    }
  };
  
  const availableNextStages = STAGE_ORDER.filter(
    (stage) => STAGE_ORDER.indexOf(stage) > STAGE_ORDER.indexOf(candidate.currentStage)
  );

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Candidate Details">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2">
                <h3 className="text-xl font-bold text-white">{candidate.name}</h3>
                <p className="text-brand-primary font-semibold">{requisition.title}</p>
                <p className="text-slate-400 text-sm mt-1">{candidate.email}</p>
                
                <div className="mt-6">
                    <h4 className="text-lg font-semibold text-slate-200 mb-3">Stage History</h4>
                    <div>
                        {candidate.stageHistory
                            .slice()
                            .sort((a,b) => new Date(a.date).getTime() - new Date(b.date).getTime())
                            .map((item, index, arr) => (
                                <TimelineItem key={index} item={item} isLast={index === arr.length - 1} />
                            ))
                        }
                    </div>
                </div>
            </div>

            <div className="md:col-span-1 bg-slate-700/50 p-4 rounded-lg">
                <h4 className="font-semibold text-slate-200 mb-3">Recruiter Info</h4>
                <p className="text-slate-300">{candidate.recruiter}</p>
                <p className="text-slate-400 text-sm">{requisition.hiringManager} (HM)</p>
                
                <div className="mt-6">
                    <a href={candidate.resumeUrl} target="_blank" rel="noopener noreferrer" className="text-brand-secondary hover:underline">
                        View Resume
                    </a>
                </div>

                <div className="mt-8 border-t border-slate-600 pt-6">
                    <h4 className="font-semibold text-slate-200 mb-3">Change Job Position</h4>
                    <select
                        value={newRequisitionId}
                        onChange={(e) => setNewRequisitionId(e.target.value)}
                        className="w-full bg-slate-600 border border-slate-500 rounded-md p-2 text-slate-100 focus:ring-2 focus:ring-brand-primary focus:outline-none"
                        aria-label="Change job position"
                    >
                        {allRequisitions.map(req => (
                            <option key={req.id} value={req.id}>{req.title}</option>
                        ))}
                    </select>
                    <button
                        onClick={handleRequisitionChange}
                        disabled={!newRequisitionId || newRequisitionId === candidate.jobRequisitionId}
                        className="w-full mt-3 bg-slate-500 text-white font-bold py-2 px-4 rounded-md hover:bg-slate-400 transition-colors disabled:bg-slate-600 disabled:cursor-not-allowed"
                    >
                        Assign to New Job
                    </button>
                </div>

                <div className="mt-8 border-t border-slate-600 pt-6">
                    <h4 className="font-semibold text-slate-200 mb-3">Update Stage</h4>
                    <select
                        value={selectedStage}
                        onChange={(e) => setSelectedStage(e.target.value as Stage)}
                        className="w-full bg-slate-600 border border-slate-500 rounded-md p-2 text-slate-100 focus:ring-2 focus:ring-brand-primary focus:outline-none"
                    >
                        <option value="" disabled>Select next stage...</option>
                        {availableNextStages.map(stage => (
                            <option key={stage} value={stage}>{stage}</option>
                        ))}
                    </select>
                    <button
                        onClick={handleStageUpdate}
                        disabled={!selectedStage}
                        className="w-full mt-3 bg-brand-primary text-white font-bold py-2 px-4 rounded-md hover:bg-brand-secondary transition-colors disabled:bg-slate-600 disabled:cursor-not-allowed"
                    >
                        Move Candidate
                    </button>
                </div>
            </div>
        </div>
    </Modal>
  );
};

export default CandidateModal;
