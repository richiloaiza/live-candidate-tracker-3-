
import React, { useRef } from 'react';
import Papa from 'papaparse';
import { BriefcaseIcon } from './icons';
import { Requisition, Candidate, Stage, StageHistoryItem } from '../types';

interface HeaderProps {
    onUploadRequisitions: (requisitions: Requisition[]) => void;
    onUploadCandidates: (candidates: Candidate[]) => void;
}

const Header: React.FC<HeaderProps> = ({ onUploadRequisitions, onUploadCandidates }) => {
  const reqInputRef = useRef<HTMLInputElement>(null);
  const candInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>, type: 'requisitions' | 'candidates') => {
      const file = event.target.files?.[0];
      if (!file) return;

      Papa.parse(file, {
          header: true,
          skipEmptyLines: true,
          complete: (results) => {
              try {
                  if (type === 'requisitions') {
                      const parsedData: Requisition[] = results.data.map((row: any) => {
                          if (!row.id || !row.title) throw new Error('Requisition CSV must have id and title.');
                          return {
                              id: row.id,
                              title: row.title,
                              openDate: row.openDate || new Date().toISOString(),
                              hiringManager: row.hiringManager || 'N/A',
                              recruiter: row.recruiter || 'N/A',
                              status: row.status || 'Open',
                              approvalDate: row.approvalDate || null,
                              briefingCallDate: row.briefingCallDate || null,
                              jobPostedDate: row.jobPostedDate || null,
                          };
                      });
                      onUploadRequisitions(parsedData);
                  } else {
                      const parsedData: Candidate[] = results.data.map((row: any) => {
                           if (!row.id || !row.name || !row.jobRequisitionId) throw new Error('Candidate CSV must have id, name, and jobRequisitionId.');
                          return {
                              id: row.id,
                              name: row.name,
                              email: row.email || 'N/A',
                              jobRequisitionId: row.jobRequisitionId,
                              currentStage: row.currentStage as Stage || Stage.APPLIED,
                              applicationDate: row.applicationDate || new Date().toISOString(),
                              stageHistory: [{ stage: (row.currentStage as Stage || Stage.APPLIED), date: (row.applicationDate || new Date().toISOString()) }],
                              recruiter: row.recruiter || 'N/A',
                              resumeUrl: row.resumeUrl || '#',
                          };
                      });
                      onUploadCandidates(parsedData);
                  }
              } catch(e) {
                  console.error('CSV Processing Error:', e);
                  alert(`Error processing CSV file: ${e instanceof Error ? e.message : 'Unknown error'}`);
              }
          },
          error: (error) => {
              console.error('CSV Parsing Error:', error);
              alert('Failed to parse CSV file. Check console for details.');
          }
      });
      
      // Reset file input to allow re-uploading the same file
      event.target.value = '';
  };

  return (
    <header className="mb-4">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
        <div>
          <div className="flex items-center space-x-3">
            <BriefcaseIcon className="h-8 w-8 text-brand-secondary" />
            <h1 className="text-3xl font-bold text-slate-100">Live Candidate Tracker</h1>
          </div>
          <p className="text-slate-400 mt-1">Real-time visibility into your recruitment pipeline.</p>
        </div>
        <div className="flex space-x-2 mt-4 sm:mt-0">
          <input type="file" ref={reqInputRef} onChange={(e) => handleFileUpload(e, 'requisitions')} className="hidden" accept=".csv" />
          <button 
            onClick={() => reqInputRef.current?.click()}
            className="bg-slate-700 hover:bg-slate-600 text-slate-100 font-semibold py-2 px-4 rounded-lg transition-colors text-sm"
          >
            Upload Requisitions (CSV)
          </button>
          
          <input type="file" ref={candInputRef} onChange={(e) => handleFileUpload(e, 'candidates')} className="hidden" accept=".csv" />
          <button 
            onClick={() => candInputRef.current?.click()}
            className="bg-brand-primary hover:bg-brand-secondary text-white font-semibold py-2 px-4 rounded-lg transition-colors text-sm"
          >
            Upload Candidates (CSV)
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
