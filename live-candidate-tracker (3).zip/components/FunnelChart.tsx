
import React, { useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Cell } from 'recharts';
import { Candidate } from '../types';
import { STAGE_ORDER } from '../constants';
import Card from './ui/Card';

interface FunnelChartProps {
  candidates: Candidate[];
}

const FUNNEL_COLORS = ['#1d4ed8', '#2563eb', '#3b82f6', '#60a5fa', '#93c5fd', '#a5b4fc', '#c7d2fe'];

const FunnelChart: React.FC<FunnelChartProps> = ({ candidates }) => {
  const funnelData = useMemo(() => {
    const counts = STAGE_ORDER.reduce((acc, stage) => {
      acc[stage] = 0;
      return acc;
    }, {} as Record<string, number>);

    candidates.forEach(candidate => {
      // A candidate counts for all stages they have passed through
      const candidateStages = new Set(candidate.stageHistory.map(s => s.stage));
       if (candidateStages.has(candidate.currentStage)) {
          STAGE_ORDER.forEach(stage => {
              if (candidate.stageHistory.some(s => s.stage === stage) || candidate.currentStage === stage) {
                   const stageIndex = STAGE_ORDER.indexOf(stage);
                   const currentStageIndex = STAGE_ORDER.indexOf(candidate.currentStage);
                   if(stageIndex <= currentStageIndex){
                       counts[stage]++;
                   }
              }
          })
      }
    });

    return STAGE_ORDER.map(stage => ({
      name: stage,
      candidates: counts[stage] || 0,
    }));
  }, [candidates]);

  return (
    <Card className="h-96">
      <h3 className="text-lg font-semibold text-slate-100 mb-4">Recruitment Funnel</h3>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={funnelData} layout="vertical" margin={{ top: 5, right: 20, left: 20, bottom: 25 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255, 255, 255, 0.1)" />
          <XAxis type="number" stroke="#94a3b8" />
          <YAxis type="category" dataKey="name" stroke="#94a3b8" width={120} tick={{ fill: '#94a3b8' }} />
          <Tooltip
            cursor={{ fill: 'rgba(255, 255, 255, 0.1)' }}
            contentStyle={{
              backgroundColor: '#1e293b',
              borderColor: '#334155',
              color: '#f1f5f9',
            }}
          />
          <Bar dataKey="candidates" barSize={25}>
            {funnelData.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={FUNNEL_COLORS[index % FUNNEL_COLORS.length]} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </Card>
  );
};

export default FunnelChart;
