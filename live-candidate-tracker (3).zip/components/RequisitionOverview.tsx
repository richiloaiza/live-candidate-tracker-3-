
import React from 'react';
import { Requisition, Candidate, Stage } from '../types';
import Card from './ui/Card';
import { AlertTriangleIcon } from './icons';
import { SLA_THRESHOLDS } from '../constants';

interface RequisitionOverviewProps {
  requisitions: Requisition[];
  candidates: Candidate[];
  selectedRequisitionId: string | null;
}

const getDaysSince = (dateString: string) => {
    return Math.floor((new Date().getTime() - new Date(dateString).getTime()) / (1000 * 60 * 60 * 24));
};

const RequisitionOverview: React.FC<RequisitionOverviewProps> = ({ requisitions, candidates, selectedRequisitionId }) => {
    
  return (
    <Card>
      <h3 className="text-lg font-semibold text-slate-100 mb-4">Requisition Overview</h3>
      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead className="border-b border-slate-700 text-sm text-slate-400">
            <tr>
              <th className="p-3">Requisition</th>
              <th className="p-3">Status</th>
              <th className="p-3">Candidates</th>
              <th className="p-3">Days Open</th>
              <th className="p-3">Recruiter</th>
              <th className="p-3">Alerts</th>
            </tr>
          </thead>
          <tbody>
            {requisitions.map(req => {
              const reqCandidates = candidates.filter(c => c.jobRequisitionId === req.id);
              const daysOpen = getDaysSince(req.openDate);
              const hasScreenedCandidates = reqCandidates.some(c => c.stageHistory.some(sh => sh.stage === Stage.SCREENING));
              const hasHiredCandidate = reqCandidates.some(c => c.currentStage === Stage.OFFER_ACCEPTED);

              const alerts = [];
              if (req.status === 'Open' && !req.briefingCallDate && daysOpen > SLA_THRESHOLDS.NO_BRIEFING_CALL) {
                alerts.push({ message: `No briefing call logged after ${SLA_THRESHOLDS.NO_BRIEFING_CALL} days`, type: 'warning'});
              }
              if (req.status === 'Open' && !hasScreenedCandidates && daysOpen > SLA_THRESHOLDS.NO_CVS_SCREENED) {
                 alerts.push({ message: `No CVs screened after ${SLA_THRESHOLDS.NO_CVS_SCREENED} days`, type: 'warning'});
              }
              if (req.status === 'Open' && !hasHiredCandidate && daysOpen > SLA_THRESHOLDS.TIME_TO_HIRE_ESCALATION) {
                 alerts.push({ message: `Time to hire escalation: ${daysOpen} days`, type: 'danger'});
              }
               if (req.status === 'Open' && reqCandidates.length > 0) {
                const lastMoveDate = Math.max(...reqCandidates.map(c => new Date(c.stageHistory[c.stageHistory.length-1].date).getTime()));
                if(getDaysSince(new Date(lastMoveDate).toISOString()) > SLA_THRESHOLDS.NO_MOVEMENT_ALERT) {
                   alerts.push({ message: `No candidate movement in >${SLA_THRESHOLDS.NO_MOVEMENT_ALERT} days`, type: 'danger' });
                }
              }

              const isSelected = req.id === selectedRequisitionId;

              return (
                <tr 
                  key={req.id} 
                  className={`border-b border-slate-700 last:border-b-0 transition-colors ${
                    isSelected 
                    ? 'bg-brand-primary/20' 
                    : 'hover:bg-slate-700/50'
                  }`}
                >
                  <td className={`p-3 transition-all ${isSelected ? 'border-l-4 border-brand-primary' : 'border-l-4 border-transparent'}`}>
                    <div className="font-semibold text-slate-100">{req.title}</div>
                    <div className="text-xs text-slate-400">{req.id}</div>
                  </td>
                  <td className="p-3">
                    <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                      req.status === 'Open' ? 'bg-green-500/20 text-green-400' : 
                      req.status === 'Closed' ? 'bg-red-500/20 text-red-400' : 'bg-yellow-500/20 text-yellow-400'}`
                    }>
                      {req.status}
                    </span>
                  </td>
                  <td className="p-3">{reqCandidates.length}</td>
                  <td className="p-3">{daysOpen}</td>
                  <td className="p-3">{req.recruiter}</td>
                  <td className="p-3">
                    <div className="flex flex-col space-y-1">
                      {alerts.map((alert, index) => (
                        <div key={index} className="flex items-center space-x-2" title={alert.message}>
                          <AlertTriangleIcon className={`w-4 h-4 ${alert.type === 'danger' ? 'text-red-500' : 'text-yellow-500'}`} />
                           <span className="text-xs text-slate-400 hidden md:inline">{alert.message}</span>
                        </div>
                      ))}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </Card>
  );
};

export default RequisitionOverview;
