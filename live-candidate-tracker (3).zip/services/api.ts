import { MOCK_CANDIDATES, MOCK_REQUISITIONS } from '../constants';
import { Candidate, Requisition, Stage } from '../types';

// Helper to get data from localStorage or fallback to mock
const getFromStorage = <T>(key: string, fallback: T[]): T[] => {
    try {
        const item = localStorage.getItem(key);
        if (item) {
            return JSON.parse(item);
        } else {
            localStorage.setItem(key, JSON.stringify(fallback));
            return fallback;
        }
    } catch (error) {
        console.error(`Error reading from localStorage key "${key}":`, error);
        return fallback;
    }
};

// Helper to save data to localStorage
const saveToStorage = <T>(key: string, data: T[]): void => {
    try {
        localStorage.setItem(key, JSON.stringify(data));
    } catch (error) {
        console.error(`Error saving to localStorage key "${key}":`, error);
    }
};

const simulateNetworkDelay = (delay = 100) => new Promise(res => setTimeout(res, delay));

export const getCandidates = async (): Promise<Candidate[]> => {
    await simulateNetworkDelay();
    return getFromStorage<Candidate>('candidates', MOCK_CANDIDATES);
};

export const getRequisitions = async (): Promise<Requisition[]> => {
    await simulateNetworkDelay();
    return getFromStorage<Requisition>('requisitions', MOCK_REQUISITIONS);
};

export const saveCandidates = async (candidates: Candidate[]): Promise<void> => {
    await simulateNetworkDelay();
    saveToStorage('candidates', candidates);
};

export const saveRequisitions = async (requisitions: Requisition[]): Promise<void> => {
    await simulateNetworkDelay();
    saveToStorage('requisitions', requisitions);
};

export const updateCandidateStage = async (candidateId: string, newStage: Stage): Promise<Candidate> => {
    await simulateNetworkDelay();
    const candidates = await getCandidates();
    const candidateIndex = candidates.findIndex(c => c.id === candidateId);
    if (candidateIndex === -1) {
        throw new Error('Candidate not found');
    }

    const updatedCandidate = { ...candidates[candidateIndex] };
    updatedCandidate.currentStage = newStage;

    // Avoid duplicating the current stage in history
    const lastHistoryStage = updatedCandidate.stageHistory[updatedCandidate.stageHistory.length - 1]?.stage;
    if (lastHistoryStage !== newStage) {
        updatedCandidate.stageHistory.push({
            stage: newStage,
            date: new Date().toISOString(),
        });
    }

    candidates[candidateIndex] = updatedCandidate;
    saveToStorage('candidates', candidates);

    return updatedCandidate;
};

export const updateCandidateRequisition = async (candidateId: string, newRequisitionId: string): Promise<Candidate> => {
    await simulateNetworkDelay();
    const candidates = await getCandidates();
    const candidateIndex = candidates.findIndex(c => c.id === candidateId);
    if (candidateIndex === -1) {
        throw new Error('Candidate not found');
    }

    const updatedCandidate = {
        ...candidates[candidateIndex],
        jobRequisitionId: newRequisitionId
    };

    candidates[candidateIndex] = updatedCandidate;
    saveToStorage('candidates', candidates);

    return updatedCandidate;
};

export const updateRequisitionDate = async (
    requisitionId: string,
    dateField: keyof Pick<Requisition, 'approvalDate' | 'briefingCallDate' | 'jobPostedDate'>
): Promise<Requisition> => {
    await simulateNetworkDelay();
    const requisitions = await getRequisitions();
    const reqIndex = requisitions.findIndex(r => r.id === requisitionId);
    if (reqIndex === -1) {
        throw new Error('Requisition not found');
    }

    const updatedRequisition = { ...requisitions[reqIndex] };
    updatedRequisition[dateField] = new Date().toISOString();

    requisitions[reqIndex] = updatedRequisition;
    saveToStorage('requisitions', requisitions);

    return updatedRequisition;
};

// --- Gemini API integration ---

/**
 * Calls Google Gemini API to generate content.
 * @param {string} prompt - The input prompt to send to Gemini.
 * @returns {Promise<any>} - The Gemini API response.
 */
export async function generateGeminiContent(prompt: string): Promise<any> {
    const apiKey = "AIzaSyDi9ScZe2YO5BVZoWpp6YgPWGlS44U1jxM"; // Do not expose in production!
    const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`;
    const body = {
        contents: [
            {
                parts: [
                    { text: prompt }
                ]
            }
        ]
    };

    const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
    });

    if (!res.ok) throw new Error("Failed to call Gemini API");
    return res.json();
}

